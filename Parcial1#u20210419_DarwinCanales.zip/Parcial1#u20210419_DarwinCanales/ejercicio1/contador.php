<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recuperar la frase ingresada
        $frase = trim($_POST['frase']);
        
        // Contar las palabras
        $palabras = str_word_count($frase);
        
        // Mostrar el resultado
        echo "<div class='result'>La frase ingresada tiene <strong>$palabras</strong> palabras.</div>";
    }
    ?>